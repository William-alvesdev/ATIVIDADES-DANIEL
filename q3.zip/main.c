#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int n = 20;
    int i;
    unsigned char pixel;
    unsigned char xmin, xmax, x;
    float x_norm;

    srand(time(NULL));

    pixel = rand() % 256;
    xmin = pixel;
    xmax = pixel;
    printf("Pixel 1: %hhu\n", pixel);

    for(i = 1; i < n; i++) {
        pixel = rand() % 256;
        printf("Pixel %d: %hhu\n", i+1, pixel);
        if(pixel < xmin) xmin = pixel;
        if(pixel > xmax) xmax = pixel;
    }

    printf("Digite o valor x para normalizar: ");
    scanf("%hhu", &x);

    if(xmax == xmin) {
        x_norm = 0.0;
    } else {
        x_norm = (float)(x - xmin) / (xmax - xmin);
    }

    printf("Menor intensidade: %hhu\n", xmin);
    printf("Maior intensidade: %hhu\n", xmax);
    printf("Valor normalizado: %.4f\n", x_norm);

    return 0;
}