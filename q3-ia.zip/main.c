#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_PIXELS 20

int main(void) {
    unsigned char xmin = 255, xmax = 0;
    unsigned char x;
    float x_norm;

    // Inicializa a semente para números aleatórios
    srand((unsigned int)time(NULL));

    printf("--- Pixels Gerados ---\n");
    for (int i = 0; i < NUM_PIXELS; i++) {
        unsigned char pixel = rand() % 256;
        printf("Pixel %2d: %3u\n", i + 1, pixel);

        if (pixel < xmin) xmin = pixel;
        if (pixel > xmax) xmax = pixel;
    }

    printf("\nMenor intensidade (xmin): %u\n", xmin);
    printf("Maior intensidade (xmax): %u\n", xmax);

    // Leitura e validação da entrada
    printf("Digite o valor x para normalizar (0-255): ");
    if (scanf("%hhu", &x) != 1) {
        printf("Entrada invalida.\n");
        return 1;
    }

    // Cálculo da Normalização Min-Max
    if (xmax == xmin) {
        x_norm = 0.0f;
    } else {
        // Conversão prévia para float para evitar underflow na subtração (x - xmin)
        x_norm = ((float)x - (float)xmin) / ((float)xmax - (float)xmin);
    }

    printf("Valor normalizado: %.4f\n", x_norm);

    return 0;
}