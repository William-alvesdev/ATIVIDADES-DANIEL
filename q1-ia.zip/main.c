#include <stdio.h>

int main(void) {
    unsigned char M, R, G, B;

    printf("Digite os valores para M, R, G e B (0-255): ");
    if (scanf("%hhu %hhu %hhu %hhu", &M, &R, &G, &B) != 4) {
        puts("Erro na leitura dos dados.");
        return 1;
    }

    // Aplica a máscara hexadecimal 0xFE (254) para zerar o LSB e insere o bit de M
    R = (R & 0xFE) | ((M >> 2) & 1);
    G = (G & 0xFE) | ((M >> 1) & 1);
    B = (B & 0xFE) | (M & 1);

    printf("Novos valores RGB:\n");
    printf("R: %u\nG: %u\nB: %u\n", R, G, B);

    return 0;
}