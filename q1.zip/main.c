#include <stdio.h>

int main()
{
    unsigned char M,R,G,B;
    unsigned char bit2,bit1,bit0;
    
    puts("Digite o valor de M:");
     scanf("%hhu",&M);
    puts("Digite o valor de R:");
     scanf("%hhu",&R);
    puts("Digite o valor de G:");
     scanf("%hhu",&G);
    puts("Digite o valor de B:");
     scanf("%hhu",&B);
    
    bit2=(M>>2)&1;
    bit1=(M>>1)&1;
    bit0=M&1;
    
    R=(R&254)|bit2;
    G=(G&254)|bit1;
    B=(B&254)|bit0;

    printf("R:%hhu \n",R);
    printf("G:%hhu\n",G);
    printf("B:%hhu",B);

    return 0;
}
