#include <stdio.h>

int main() {
    int soma = 0, contador = 0, numero = 0;

    printf("Digite os pixels (0 a 255). Digite -1 para parar:\n");

    while (numero != -1) {
        printf("Pixel: ");
        scanf("%d", &numero);

        if (numero != -1 && numero >= 0 && numero <= 255) {
            soma += numero;
            contador++;
        } else if (numero != -1) {
            printf("Valor invalido! Digite entre 0 e 255 ou -1 para sair.\n");
        }
    }

    printf("Soma = %d\n", soma);
    printf("Quantidade = %d\n", contador);

    return 0;
}