#include <stdio.h>

int main(void) {
    int soma = 0, contador = 0, numero = 0;

    printf("Digite os pixels (0 a 255). Digite -1 para encerrar:\n");

    while (1) {
        printf("Pixel: ");
        
        // Validação da leitura
        if (scanf("%d", &numero) != 1) {
            printf("Entrada invalida! Insira apenas numeros inteiros.\n");
            break;
        }

        // Condição de parada (sentinela)
        if (numero == -1) {
            break;
        }

        // Validação da faixa do pixel
        if (numero >= 0 && numero <= 255) {
            soma += numero;
            contador++;
        } else {
            printf("Valor fora da faixa (0-255)! Tente novamente.\n");
        }
    }

    printf("\n--- Resultados ---\n");
    printf("Soma total = %d\n", soma);
    printf("Quantidade de pixels validos = %d\n", contador);

    if (contador > 0) {
        printf("Media dos pixels = %.2f\n", (float)soma / contador);
    } else {
        printf("Nenhum pixel valido foi inserido.\n");
    }

    return 0;
}