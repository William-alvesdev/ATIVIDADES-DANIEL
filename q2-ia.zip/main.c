#include <stdio.h> 

int main(void) {
    int n;

    printf("Quantas amostras?\n");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Quantidade invalida de amostras.\n");
        return 1;
    }

    for (int i = 1; i <= n; i++) {
        int x1;
        printf("Digite o peso da amostra %d: ", i);
        if (scanf("%d", &x1) != 1) {
            printf("Entrada invalida.\n");
            return 1;
        }

        int v_anterior = x1 - 1;
        int v_posterior = x1 + 1;
        int media = (v_anterior + x1 + v_posterior) / 3;

        printf("O valor das amostras ficam: %d, %d, %d\n", v_anterior, x1, v_posterior);
        printf("A media fica: %d\n\n", media);
    }

    return 0;
}