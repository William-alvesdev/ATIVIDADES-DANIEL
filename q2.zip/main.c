#include <stdio.h>
int main()
{
    int i,n,x1,y;
    printf("Quantas amostras?\n");
    scanf("%d",&n);
    
    for(i=2;i<=n-1;i++)
    {
    y=(x1-1+x1+x1+1)/3;
    printf("Digite o peso da amostra?");
    scanf("%d",&x1);
    printf("O valor das amostras ficam %d %d %d \n",x1-1,x1,x1+1);
    printf("A media fica:%d",(x1-1+x1+x1+1)/3);
    }

    return 0;
}
